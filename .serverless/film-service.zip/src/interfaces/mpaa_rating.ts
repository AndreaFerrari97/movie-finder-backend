export interface MpaaRating {
    mpaa_rating_id: number;
    rating: string;
}

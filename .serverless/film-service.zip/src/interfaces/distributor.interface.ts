export interface Distributor {
    distributor_id: number;
    name: string;
}
